<?php
$license = 'Leased-01c152715fa1e8200921';
$db_host = 'localhost';
$db_username = 'icellpho_phones';
$db_password = 'Whmcs!4L';
$db_name = 'icellpho_whmcs';
$cc_encryption_hash = "5jZgzd7Y9ykQRQKOYoNiGK5H2s1uxvusEkz4owSoV34CJEhxTUFqvBYoUPIha3AF";
$templates_compiledir = 'templates_c';
$mysql_charset = 'utf8';