Please don't remove the ideal.cer and add your own certificate and key in this map.

- ideal.cer (allready present)
- merchantprivatekey.pem
- cert.cer

You may create them using OpenSSL. Instructions can be found in your Ideal Postbank/ING Manual
or you may have a look here: http://www.morningtime.nl/article/openssl-certificaat-maken-voor-ideal.html

Please, Do not forget to upload cert.cer to you Postbank/ING Ideal Dashboard!